package lab5_1.rulesets;

import java.awt.Component;

public interface RuleSet {
	public void applyRules(Object ob) throws RuleException;
}
