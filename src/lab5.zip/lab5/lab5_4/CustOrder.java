package lab5_4;

public interface CustOrder {

    public String toString();
}
