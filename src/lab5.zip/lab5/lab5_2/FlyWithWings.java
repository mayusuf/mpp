package lab5_2;

public class FlyWithWings  implements FlyBehavior{
    public void fly() {
        System.out.println("fly with wings");
    }
}
