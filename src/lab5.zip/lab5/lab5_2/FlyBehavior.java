package lab5_2;

public interface FlyBehavior {
    void fly();
}
