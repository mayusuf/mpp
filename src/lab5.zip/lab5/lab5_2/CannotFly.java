package lab5_2;

public class CannotFly implements FlyBehavior{
    public void fly() {
        System.out.println("cannt fly");
    }
}
