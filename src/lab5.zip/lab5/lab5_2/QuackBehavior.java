package lab5_2;

public interface QuackBehavior {
    void quack();
}
