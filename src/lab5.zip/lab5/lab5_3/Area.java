package lab5_3;

public interface Area {
    public double computeArea();
}
