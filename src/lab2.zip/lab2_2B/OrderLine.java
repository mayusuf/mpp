package lab2_2B;

public class OrderLine {

    private Order order;
    public OrderLine(Order order){
        this.order = order;
    }
}
