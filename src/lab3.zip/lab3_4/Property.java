package lab3_4;

public class Property {

    public double rent;

    public Property(double rent) {

        this.rent = rent;
    }

    public double computeRent() {
        return rent;
    }

}
