package lab3_3B;


public class Main {
    public static void main(String[] args) {

        Circle c = new Circle(10);
        Cylinder cy = new Cylinder(5, 4);

        System.out.println(c);
        System.out.println(cy);
    }
}
